class Pawn < piece

end