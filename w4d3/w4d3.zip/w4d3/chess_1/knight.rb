class Knight < Piece 
end