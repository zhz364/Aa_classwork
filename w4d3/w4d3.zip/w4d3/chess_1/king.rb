class King < Piece 

end