import warmUp from "./warmup";
import clock from "./clock";
import * as dropdown from "./drop_down.js"
window.dogLinkCreator = dropdown.dogLinkCreator

window.attachDogLinks = dropdown.attachDogLinks

