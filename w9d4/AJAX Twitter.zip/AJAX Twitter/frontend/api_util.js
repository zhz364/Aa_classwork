const APIUtil = {
    followUser: id => {
        // ...
    },

    unfollowUser: id => {
        // ...
    }
};

module.exports = APIUtil;