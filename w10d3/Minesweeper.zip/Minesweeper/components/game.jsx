import React from "react"

const Game = () => {

    return (<div>GAME GOES HERE</div>)
}

export default Game;